.. AUTO-GENERATED FILE -- DO NOT EDIT!

auth.thread
===========

Module: :mod:`auth.thread`
--------------------------
.. automodule:: zmq.auth.thread

.. currentmodule:: zmq.auth.thread

Classes
-------


:class:`ThreadAuthenticator`
~~~~~~~~~~~~~~~~~~~~~~~~~~~~


.. autoclass:: ThreadAuthenticator
  :members:
  :undoc-members:
  :inherited-members:

